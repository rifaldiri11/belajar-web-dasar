<?php
session_start();

if (!isset($_SESSION["login"])) {
  header("Location: login.php");
  exit;
}
require 'functions.php';

// mengambil data dari queri
$id = $_GET['id'];
// function query mengambil data dari table kamar yang dimana berupa id dan index 0
$row = query("SELECT * FROM data_kamar WHERE id = $id")[0];


// cek button submit telah diekan atau belum 
if (isset($_POST["submit"])) {
  // mengecek apakah data berhasil di ubah  function ubah lebih dari 0
  if (ubah($_POST) > 0) {
    echo "
    <script>
      alert('Data Berhasil Di ubah!');
      document.location = 'index.php';
    </script>
    ";
  } else {
    echo " 
    <script>
      alert('Data Gagal Di ubah!');
      document.location = 'index.php';
    </script>";
  }
}
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

  <title>Hello, world!</title>
</head>

<body>

  <div class="container">
    <div class="row">
      <div class="col">
        <!-- Navigasi -->
        <ul class="nav nav-pills mt-3">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="index.php">HOME</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">PROPERTI</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Detail Properti</a></li>
              <li><a class="dropdown-item" href="#">Gambar Kamar</a></li>
              <li><a class="dropdown-item" href="tambah.php">Tambah Data Kamar</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="#">Skor Konten</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
        </ul>
        <!-- navigasi end -->

        <h3 class="my-3">Daftar Ubah Data Room Properti</h3>
        <form accept="" method="POST" enctype="multipart/form-data">
          <input type="hidden" name="id" value="<?= $row['id']; ?>">
          <input type="hidden" name="fotoLama" value="<?= $row['foto']; ?>">
          <div class="card" style="width: 30rem;">
            <ul class="list-group list-group-flush">
              <li class="list-group-item">
                <label for="foto" class="form-label">Foto Room :</label>
                <img src="img/room/<?= $row['foto']; ?>" width="80%" alt="">
                <input type="file" class="form-control" id="foto" name="foto">
              </li>
              <li class="list-group-item">
                <label for="nama" class="form-label">Nama Room :</label>
                <input type="text" class="form-control" id="nama" name="nama" required value="<?= $row['nama']; ?>">
              </li>
              <li class="list-group-item">
                <label for="tipe" class="form-label">Tipe Room :</label>
                <input type="text" class="form-control" id="tipe" name="tipe" value="<?= $row['tipe']; ?>">
              </li>
              <li class="list-group-item">
                <label for="size" class="form-label">Room size :</label>
                <input type="number" class="form-control" id="size" name="size" value="<?= $row['size']; ?>">
              </li>
              <li class="list-group-item">
                <label for="bed" class="form-label">Bed Type :</label>
                <input type="text" class="form-control" id="bed" name="bed" value="<?= $row['bed']; ?>">
              </li>
              <li class="list-group-item">
                <label for="max_occ" class="form-label">Maximum Occupancy :</label>
                <input type="text" class="form-control" id="max_occ" name="max_occ" value="<?= $row['max_occ']; ?>">
              </li>
              <li class="list-group-item">
                <label for="min_rate" class="form-label">Minimum Rate :</label>
                <input type="text" class="form-control" id="min_rate" name="min_rate" value="<?= $row['min_rate']; ?>">
              </li>
              <li class="list-group-item">
                <button type="submit" name="submit" class="btn btn-success mt-3">Ubah Data Kamar</button>
                <a href="index.php">
                  <button type="button" class="btn btn-warning mt-3 ">Kembali</button>
                </a>
              </li>

            </ul>
          </div>
        </form>
        <br><br><br><br></b>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous">
    < />

    <
    !--Option 2: Separate Popper and Bootstrap JS-- >
      <
      !--
      <
      script src = "https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"
    integrity = "sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp"
    crossorigin = "anonymous" >
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
  --> -->
</body>

</html>