<?php

$conn = mysqli_connect("localhost", "root", "", "properti");

function query($query)
{
  global $conn;
  $result = mysqli_query($conn, $query);
  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}

function tambah($data)
{
  global $conn;
  $foto = upload();
  if (!$foto) {
    return false;
  }
  $nama = htmlspecialchars($data["nama"]);
  $tipe = htmlspecialchars($data["tipe"]);
  $size = htmlspecialchars($data["size"]);
  $bed = htmlspecialchars($data["bed"]);
  $max_occ = htmlspecialchars($data["max_occ"]);
  $min_rate = htmlspecialchars($data["min_rate"]);


  $query = "INSERT INTO data_kamar VALUES('','$foto','$nama', '$tipe', '$size', '$bed', '$max_occ', '$min_rate')";

  mysqli_query($conn, $query);

  // mengembalikan nilai dari variable conn bahwa ada yang di tambah
  return mysqli_affected_rows($conn);
}

function upload()
{
  $namaFile     = $_FILES['foto']['name'];
  $ukuranFile   = $_FILES['foto']['size'];
  $error        = $_FILES['foto']['error'];
  $tmpFile      = $_FILES['foto']['tmp_name'];

  // cek apakah tidak ada foto yang diupload
  if ($error === 4) {
    echo "
    <script>
      alert('Pilih foto terlebih dahulu');
    </script>
    ";
    return false;
  }
  // cek apakah yang diupload adalah foto
  $ekstensiFotoValid = ['jpeg', 'jpg', 'png'];
  $ekstensiFoto = explode('.', $namaFile);
  $ekstensiFoto = strtolower(end($ekstensiFoto));
  if (!in_array($ekstensiFoto, $ekstensiFotoValid)) {
    echo "
    <script>
      alert('yang diupload bukan foto');
    </script>
    ";
    return false;
  }

  //cek jika ukuranya terlalu besar
  if ($ukuranFile > 1000000) {
    echo "
    <script>
      alert('ukuran foto terlalu besar!');
    </script>
    ";
    return false;
  }

  // lolos pengecekan foto siap di upload
  // generate nama foto baru
  $namaFileBaru = uniqid();
  $namaFileBaru .= '.';
  $namaFileBaru .= $ekstensiFoto;
  move_uploaded_file($tmpFile, 'img/room/' . $namaFileBaru);
  return $namaFileBaru;
}

function hapus($id)
{
  global $conn;
  mysqli_query($conn, "DELETE FROM data_kamar WHERE id = $id");

  return mysqli_affected_rows($conn);
}

function ubah($data)
{
  global $conn;

  $id = $data["id"];
  $fotoLama = $data["fotoLama"];
  $foto = htmlspecialchars($data["foto"]);
  $nama = htmlspecialchars($data["nama"]);
  $tipe = htmlspecialchars($data["tipe"]);
  $size = htmlspecialchars($data["size"]);
  $bed = htmlspecialchars($data["bed"]);
  $max_occ = htmlspecialchars($data["max_occ"]);
  $min_rate = htmlspecialchars($data["min_rate"]);

  // cek apakah user pilih foto baru atau tidak
  if ($_FILES['foto']['error'] === 4) {
    $foto = $fotoLama;
  } else {
    $foto = upload();
  }

  $query = "UPDATE data_kamar SET
              foto     = '$foto',
              nama     = '$nama',
              tipe     = '$tipe',
              size     = '$size',
              bed      = '$bed',
              max_occ  = '$max_occ',
              min_rate = '$min_rate'
            WHERE id   = $id
            ";

  mysqli_query($conn, $query);

  // mengembalikan nilai dari variable conn bahwa ada yang di ubah bernilai 1
  return mysqli_affected_rows($conn);
}

function cari($keyword)
{
  $query = "SELECT * FROM data_kamar 
            WHERE
            nama LIKE '%$keyword%' OR
            tipe LIKE '%$keyword%' OR
            size LIKE '%$keyword%' OR
            bed LIKE '%$keyword%' OR
            max_occ LIKE '%$keyword%' OR
            min_rate LIKE '%$keyword%' 

            ";
  return query($query);
}

function registrasi($data)
{
  global $conn;
  $username = strtolower(stripslashes($data["username"]));
  $password = mysqli_real_escape_string($conn, $data["password"]);
  $password2 = mysqli_real_escape_string($conn, $data["password2"]);

  // cek apakah username sudah ada atau belum
  $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
  if (mysqli_fetch_assoc($result)) {
    echo "
    <script>
      alert('username sudah terdaftar');
    </script>
    ";
    return false;
  }

  // cek konfirmasi password
  if ($password !== $password2) {
    echo "
    <script>
      alert('konfirmasi password tidak sama');
    </script>
    ";
    return false;
  }
  // enkripsi password
  $password = password_hash($password, PASSWORD_DEFAULT);

  // tambahkan user baru ke database
  mysqli_query($conn, "INSERT INTO user VALUES('','$username', '$password')");

  return mysqli_affected_rows($conn);
}
