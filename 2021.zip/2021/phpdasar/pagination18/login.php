<?php
require 'functions.php';
session_start();

// // cek cookie
if (isset($_COOKIE['id']) && isset($_COOKIE['key'])) {
  $id = $_COOKIE['id'];
  $key = $_COOKIE['key'];

  // ambil username berdasarkan id
  $result = mysqli_query($conn, "SELECT username FROM user WHERE id = $id");
  $row = mysqli_fetch_assoc($result);

  // cek cookie dan username
  if ($key === hash('sha256', $row['username'])) {
    $_SESSION['login'] = true;
  }
}



if (isset($_SESSION["login"])) {
  header("Location: index.php");
}


if (isset($_POST["login"])) {
  $username = $_POST["username"];
  $password = $_POST["password"];

  $result = mysqli_query($conn, "SELECT * FROM user WHERE username ='$username'");

  // cek username
  if (mysqli_num_rows($result) === 1) {
    // cek password
    $row = mysqli_fetch_assoc($result);
    if (password_verify($password, $row["password"])) {

      // set session
      $_SESSION["login"] = true;

      // cek remember / ingat saya
      if (isset($_POST['remember'])) {
        // buat cookie

        setcookie('id', $row['id'], time() + 60);
        setcookie('key', hash('sha256', $row['username']), time() + 60);
      }

      header("location: index.php");
      exit;
    }
  }
  $error = true;
}

?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

  <title>Hello, world!</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col">
        <!-- Navigasi -->

        <!-- navigasi end -->

        <div class="card text-center mt-5" style="width: 450px; margin-left: auto; margin-right: auto;">

          <h3 class="my-3">Login Propertie</h3>
          <?php if (isset($error)) : ?>
            <p class="fw-lighter" style="color:brown; font-size:large ">username / password salah</p>
            <p class="fw-lighter" style="color:brown; font-size:large ">Masukkan username / password yang telah di registrasi sebelumnya</p>
          <?php endif; ?>
          <form accept="" method="POST">
            <div class="card">
              <ul class="list-group list-group-flush">
                <li class="list-group-item">
                  <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" id="username" aria-describedby="emailHelp" autofocus>
                  </div>
                </li>
                <li class="list-group-item ">
                  <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="password">
                  </div>
                </li>
                <div class="mt-3">
                  <input type="checkbox" name="remember" class="form-check-input" id="remember">
                  <label class="form-check-label" for="remember">Ingat saya!</label>
                </div>
                <li class="list-group-item">
                  <div class="">
                    <button type="submit" name="login" class="btn btn-success mt-3">Login</button>
                    <a href="registrasi.php">
                      <button type="button" class="btn btn-warning mt-3 ">Registrasi</button>
                    </a>
                    <p class=" text-muted mt-3">copyright 2021 PT rifaldiri. all rights reserved</p>
                  </div>
                </li>
              </ul>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
</body>

</html>