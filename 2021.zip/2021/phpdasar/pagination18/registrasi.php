<?php

require 'functions.php';

if (isset($_POST["register"])) {
  if (registrasi($_POST) > 0) {
    echo "
      <script>
        alert('user berhasil di tambah');
      </script>
    ";
  } else {
    echo mysqli_error($conn);
  }
}

?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

  <title>Hello, world!</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col">
        <!-- Navigasi -->

        <!-- navigasi end -->

        <h3 class="my-3">Halaman Regitrasi</h3>
        <ul>
          <li>
            <p class="fw-lighter">Masukkan nama dengan benar</p>
          </li>
          <li>
            <p class="fw-lighter">Konfirmasi password harus sama</p>
          </li>
        </ul>
        <form accept="" method="POST">
          <div class="card" style="width: 30rem;">
            <ul class="list-group list-group-flush">
              <li class="list-group-item">
                <div class="mb-3">
                  <label for="username" class="form-label">Username</label>
                  <input type="text" name="username" class="form-control" id="username" aria-describedby="emailHelp">
                </div>
              </li>
              <li class="list-group-item">
                <div class="mb-3">
                  <label for="password" class="form-label">Password</label>
                  <input type="password" name="password" class="form-control" id="password">
                </div>
              </li>
              <li class="list-group-item">
                <div class="mb-3">
                  <label for="password2" class="form-label">Konfirmasi Password</label>
                  <input type="password" name="password2" class="form-control" id="password2">
                </div>
              </li>
              <li class="list-group-item">
                <div class="">
                  <button type="submit" name="register" class="btn btn-success mt-3">Registrasi</button>
                  <a href="index.php">
                    <button type="button" class="btn btn-warning mt-3 ">Kembali</button>
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>

</html>