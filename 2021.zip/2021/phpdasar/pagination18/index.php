<?php
session_start();
require 'functions.php';

if (!isset($_SESSION["login"])) {
  header("Location: login.php");
  exit;
}

// pagination
// pagination
// konfigurasi
$jumlahDataPerHalaman = 4;
$jumlahData = count(query("SELECT * FROM data_kamar"));
$jumlahHalaman = ceil($jumlahData / $jumlahDataPerHalaman);
$halamanAktif = (isset($_GET["halaman"])) ? $_GET["halaman"] : 1;
$awalData = ($jumlahDataPerHalaman * $halamanAktif) - $jumlahDataPerHalaman;

$room = query("SELECT * FROM data_kamar LIMIT $awalData, $jumlahDataPerHalaman");


// tombol cari di tekan

if (isset($_POST["cari"])) {
  $room = cari($_POST["keyword"]);
}



?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

  <title>Hello, world!</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

  <div class="container">
    <div class="row">
      <div class="col">
        <!-- Navigasi -->
        <ul class="nav nav-pills mt-3">
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="index.php">HOME</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">PROPERTI</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Detail Properti</a></li>
              <li><a class="dropdown-item" href="#">Gambar Kamar</a></li>
              <li><a class="dropdown-item" href="tambah.php">Tambah Data Kamar</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="#">Skor Konten</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="registrasi.php">
              <button type=" button" class="btn btn-primary ">Registrasi</button></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="login.php">
              <button type=" button" class="btn btn-primary ">Login</button>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php" onclick="return confirm ('yakin ingin keluar?')">
              <button type=" button" class="btn btn-warning ">Logout</button>
            </a>
          </li>
        </ul>
        <!-- navigasi end -->

        <h3 class="my-3">Daftar Data Room Properti</h3>
        <a href="tambah.php">
          <button type="button" class="btn btn-primary mb-3">Tambah Data Room</button>
        </a>
        <!-- SERACH -->
        <form accept="" method="POST">
          <div class="mb-3">
            <div class="col-4">
              <div class="input-group flex-nowrap">
                <input type="text" name="keyword" for="cari" class="form-control" autofocus placeholder="masukkan kata kunci pencarian..." autocomplete="off">
                <button type="submit" name="cari" id="cari" class="btn btn-primary">Cari!</button>
              </div>
            </div>
          </div>
        </form>
        <!-- ENDSEARCH -->

        <table class="table table-striped">
          <thead>
            <tr>
              <th scope="col">Foto</th>
              <th scope="col">Nama Room</th>
              <th scope="col">Tipe Room</th>
              <th scope="col">Size Room</th>
              <th scope="col">Tipe Beh</th>
              <th scope="col">Maximum Occupancy</th>
              <th scope="col">Minimum Rate</th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($room as $row) : ?>
              <tr>
                <td><img src="img/room/<?= $row['foto']; ?>" width="200" alt=""></td>
                <td text-align="center"><?= $row['nama']; ?></td>
                <td><?= $row['tipe']; ?></td>
                <td><?= $row['size']; ?></td>
                <td><?= $row['bed']; ?></td>
                <td><?= $row['max_occ']; ?></td>
                <td><?= $row['min_rate']; ?></td>
                <td>
                  <a href="ubah.php?id=<?= $row['id']; ?>">
                    <button type="button" class="btn btn-success btn-sm">Ubah</button>
                  </a>
                </td>
                <td>
                  <a href="hapus.php?id=<?= $row['id']; ?>" onclick="return confirm ('yakin akan dihapus?')">
                    <button type=" button" class="btn btn-danger btn-sm">Hapus</button>
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <!-- PAGINATION -->

        <nav aria-label="Page navigation example" class="float-left mb-5">
          <ul class="pagination">
            <li class="page-item"><a class="page-link" href="?halaman=1">&laquo;</a></li>
            <li class="page-item">
              <?php if ($halamanAktif > 1) : ?>
                <a class="page-link" href="?halaman=<?= $halamanAktif - 1; ?>">Previous</a>
              <?php endif; ?>
            </li>
            <?php for ($i = 1; $i <= $jumlahHalaman; $i++) : ?>
              <?php if ($i == $halamanAktif) : ?>
                <li class="page-item active">
                  <a class="page-link " href="?halaman=<?= $i; ?>"><?= $i; ?></a>
                </li>
              <?php else : ?>
                <li class="page-item">
                  <a class="page-link" href="?halaman=<?= $i; ?>"><?= $i; ?></a>
                </li>
              <?php endif; ?>
            <?php endfor; ?>
            </li>
            <?php if ($halamanAktif < $jumlahHalaman) : ?>
              <li class="page-item">
                <a class="page-link" href="?halaman=<?= $halamanAktif + 1; ?>">Next</a>
              </li>
            <?php endif; ?>
            <li class="page-item"><a class="page-link" href="?halaman=<?= $jumlahHalaman; ?>">&raquo;</a></li>
          </ul>
        </nav>
        <!-- END PAGINATION -->
        <div class="text-center mt-5" style="width: 450px; margin-left: auto; margin-right: auto;">
          <p class=" text-muted mt-3">copyright 2021 PT rifaldiri. all rights reserved</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
    -->
</body>

</html>