<?php
// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "hospitality");

// mengambil tabel / query
$result = mysqli_query($conn, "SELECT * FROM room");

/*
ambil data (fetch) room dari object result
mysqli_fetch_row() mengembalikan array numerik
mysqli_fetch_assoc() mengembalikan berdasarkan nama key / asosiatif
mysqli_fetch_array() mengembalikan keduanya dari numerik dan asosiatif
mysqli_fetch_object() 
*/
// pengulangan
// while ($room = mysqli_fetch_assoc($result)) {
//   var_dump($room);
// }


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hospitality</title>
</head>

<body>
  <h1>List Room</h1>

  <table border="1" cellpadding="10" cellspacing="0">
    <tr>
      <th>no</th>
      <th>tipe</th>
      <th>nama</th>
      <th>harga</th>
      <th>ketersediaan</th>
      <th>gambar</th>
      <th>lebih</th>
    </tr>

    <?php $i = 1; ?>
    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
      <tr>
        <td><?= $i; ?></td>
        <td><?= $row["tipe"]; ?></td>
        <td><?= $row["nama"]; ?></td>
        <td><?= $row["harga"]; ?></td>
        <td><?= $row["ketersediaan"]; ?></td>
        <td><img src="img/<?= $row["gambar"]; ?>" alt=""></td>
        <td>
          <a href="">ubah</a> |
          <a href="">hapus</a>
        </td>
      </tr>
      <?php $i++ ?>
    <?php endwhile; ?>

  </table>
</body>

</html>