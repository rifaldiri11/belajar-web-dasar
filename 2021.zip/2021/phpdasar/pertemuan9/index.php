<?php

require 'functions.php';
$room = query("SELECT * FROM room");


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hospitality</title>
</head>

<body>
  <h1>List Room</h1>
  <a href="">Allotment</a>
  <br>
  <table border="0" cellpadding="10" cellspacing="0">
    <br>
    <tr>
      <th>No</th>
      <th>Tipe</th>
      <th>Nama</th>
      <th>Harga</th>
      <th>Ketersediaan</th>
      <th>Gambar</th>
      <th>Lebih</th>
    </tr>

    <?php $i = 1; ?>
    <?php foreach ($room as $row) : ?>
      <tr>
        <td><?= $i; ?></td>
        <td><?= $row["tipe"]; ?></td>
        <td><?= $row["nama"]; ?></td>
        <td><?= $row["harga"]; ?></td>
        <td align="middle"><?= $row["ketersediaan"]; ?></td>
        <td><img src="img/<?= $row["gambar"]; ?>" alt=""></td>
        <td>
          <a href="">ubah</a> |
          <a href="">hapus</a>
        </td>
      </tr>
      <?php $i++ ?>
    <?php endforeach; ?>

  </table>
</body>

</html>