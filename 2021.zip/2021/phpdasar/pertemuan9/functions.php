<?php

// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "hospitality");

function query($query)
{
  global $conn; //variable scope mengambil variable diluar lingkuangan function
  $result = mysqli_query($conn, $query); // membuat variable result untuk mengambil table room
  $rows = []; // membuat sebuah wadah berupa array kosong
  // lalu membuat sebuah perulangan mengunakan while
  // menggunakan mysqli_fetch_assoc 
  // dan dimasukkan ke dalam $rows array kosong
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}
