<?php

session_start();

$_SESSION["nama"] = "Muhamad Rifaldi" . PHP_EOL;
$_SESSION["ttl"] = "palembang 16 november 1999";
