<?php

session_start();

echo $_SESSION["nama"] . PHP_EOL;
echo $_SESSION["ttl"];
