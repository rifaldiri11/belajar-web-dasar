<?php
// koneksi nama local database, nama username database, password database, nama database
$conn = mysqli_connect("localhost", "root", "", "properti");

// function menselect table pada database
function query($query)
{
  global $conn;
  $result = mysqli_query($conn, $query); // query table dengan mysqli_query / select table
  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) { // memperulang data dan mengambil data menggunakan fetch_assoc / array asosiatip
    $rows[] = $row;
  }
  return $rows;
}
