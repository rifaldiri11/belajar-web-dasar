<?php
require 'functions.php';
$room = query("SELECT * FROM ujian");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Propertie</title>
</head>

<body>
  <h1>Data data</h1>
  <a href="tambah.php">Tambah data Baru</a>
  <br>
  <table border="0" cellpadding="10" cellspacing="0">
    <br>
    <tr>
      <th>No</th>
      <th>nim</th>
      <th>nama</th>
      <th>jurusan</th>
    </tr>

    <?php $i = 1; ?>
    <?php foreach ($room as $row) : ?>
      <tr>
        <td><?= $i; ?></td>
        <td><?= $row["nim"]; ?></td>
        <td><?= $row["nama"]; ?></td>
        <td><?= $row["jurusan"]; ?></td>
        <td>
          <a href="">ubah</a> |
          <a href="">hapus</a>
        </td>
      </tr>
      <?php $i++ ?>
    <?php endforeach; ?>

  </table>
</body>

</html>