<?php

// membuat function dan constant di dalam sebuah namespace
namespace Helper;

function helpMe()
{
    echo "ini function di dalam namespace" . PHP_EOL;
}
function helpMe2()
{
    echo "ini function di dalam namespace yang kedua" . PHP_EOL;
}
const APPLICATION = "ini adalah constant Belajar PHP OOP" . PHP_EOL;
