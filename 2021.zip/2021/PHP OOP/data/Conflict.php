<?php

// cara membuat class yang sama dalam 1 file menggunakan 'namespace NamaDatanya{}'
namespace Data\One {
    class Conflict
    {
    }
    class Dummy
    {
    }
    class Sample
    {
    }
}

namespace Data\Two {
    class Conflict
    {
    }
}
