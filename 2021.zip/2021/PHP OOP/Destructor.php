<?php

require_once "data/Person.php";

$eko = new Person("eko", "palembang");
$joko = new Person("joko", "palembang");

echo "Program Selesai" . PHP_EOL;
