<?php

require_once "data/Person.php";

$rifaldi = new Person("Muhamad Rifaldi", null);
var_dump($rifaldi);
