<?php

require_once "data/Person.php";

$person = new Person("Muhamad Rifaldi", "Palembang");

var_dump($person);
