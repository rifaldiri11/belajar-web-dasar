/*
Perulangan While
var jmlKamar = 120
var noKamar = 111;
while(noKamar <= jmlKamar){

  console.log('Kamar ' + noKamar + ' Terjual');

noKamar++;
}
*/
/*
Perulangan for

for(noKamr = 100; noKamr <= 120; noKamr++){
  console.log('Kamar ' +noKamr+' terjual');
}

*/
var s="";
for (var i = 0; i < 5 ; i++){
  for(var j = 0; j <= i; j++){
    s += "*";
    
  }
  
  s += '\n'
  
}
console.log(s);
var r="";
for (var i = 5; i > 0 ; i--){
  for(var j = 0; j < i; j++){
    r += "*";
    
  }
  
  r += '\n'
  
}
console.log(r);
