var tanya = true;
while (tanya){
  // menangkap pilihan player
  var p = prompt('==== LEtS CHOOSE LIST DIBAWAH UNTUK MEMULAI GAME :P : ==== \n1. Gunting \n2. Batu \n3. Kertas'  );

  // menangkap pilihan computer
  // membangkitkan bilangan random
  // menggunakan  method Math.random dari JS
  var comp = Math.random();

  if (comp < 0.34){
    comp = 'Batu';
  }else if (comp >= 0.34 && comp <= 0.67){
    comp = 'Gunting';
  }else{
    comp = 'Kertas';
  }

  console.log (comp);

  var hasil ='';
  //menentukan rules
  if (p == comp){
    hasil = '***Yah SERI! Ayo Coba Lagi***';
  }else if (p == 'Gunting'){
    hasil = (comp == 'Batu') ? '***KALAH :`( ***' : '***KAMU MENANG!***';
  } else if( p == 'Batu'){
    hasil = (comp == 'Kertas') ? '***KALAH :`( ***' : '***KAMU MENANG!***';
  } else if (p == 'Kertas'){
    hasil = (comp == 'Gunting') ? '***KALAH :`( ***' : '***KAMU MENANG!***';
  }else{
    hasil = 'Ketikkan Pilihan Sesuai Daftar :)';
  }


  // tampilkan hasilnya
  alert('Kamu Memilih                     : ' + p + '\nDan Computer Memilih      : ' + comp + '\nMaka Hasilnya Adalah        :  ' + hasil );
  tanya = confirm('Baiklah Kita Mulai Lagi ? ')
}

alert('Terima Kasih Sudah Bermain')