/*

var a = 1; // variable scope global
function Rifaldi(a){
  console.log(a); // variable scope local
}

Rifaldi(3);
console.log(a);

*/

// function rekursif memanggil function itu sendiri
// cara memberhentikanay dengan menggunakan base case
// menambahkan if kondisi di dalam functionya

// function tampilAngka(n){
//   if(n == 0){
//     return;
//   }
//   console.log(n);
//   return tampilAngka(n-1);
// }

// tampilAngka(5);

var tampilAngka = function(n){

  if(n == 20){
    return;
  }

  console.log(n);
  return tampilAngka(n+1)
}
tampilAngka(1);