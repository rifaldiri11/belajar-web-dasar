// popup box alert, prompt, confirm
// alert
// alert("Hello JavaScript");

// prompt opsi true or false
// var suka = prompt('Apa yang kamu suka??');


// // confirm
// confirm("Apakah Kamu Yakin??");

// var tes = confirm("Apakah Kamu suka saya");
// if (tes === true){
//   alert("Saya Sangat Bahagia : )")
// }else{
//   alert("Saya Sungguh Kecewa :(")
// }


/* 
penggabungan anatara alert prompt confirm dan perulangan while
*/
alert('Hello Selamat Datang');
var lagi = true;

while(lagi === true){
  var nama = prompt('Masukkan Nama Kamu');

  alert ('Halo ' + nama);

  lagi = confirm('Mau Coba Lagi');
}

alert('Terima Kasih');