<?php
$name = "Rifaldi";
// $name = null;

$age = null;

echo "Name : ", $name, "\n";
echo "Age : ", $age, "\n";


// is NULL
// $name = "Rifaldi";
echo "Is age Null ? : ", is_null($age), "\n";

/*
// Unset menghapus permanen
$contoh = "Rifaldi";
unset($contoh);

echo "Coba ini : ", var_dump($contoh);
*/

// isset mengecek data ada atau tidak ada 
$contoh = [
    "null"
];
unset($contoh);

var_dump(isset($contoh));
