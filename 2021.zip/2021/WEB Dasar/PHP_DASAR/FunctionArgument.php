<?php
// Function dan parameter/argumnet
function sayHello($name)
{
    echo "Hello $name"  . PHP_EOL;
}

sayHello("Muhamad");
sayHello("Rifaldi");
sayHello("Aldi" . "\n");

// Function dengan default Argument Value
function sayHai($name = "Anonymous")
{
    echo "Hai $name" . PHP_EOL;
}

sayHai();
sayHai("Muhamad");
sayHai("Rifaldi \n");


// Function dengan default Argument Value 2 Parameter
function sayHi($firstname, $lastname = "hello")
{
    echo "Hai $firstname $lastname" . PHP_EOL;
}

sayHi("Muhamad");
sayHi("Rifaldi");
sayHi("Muhamad", "Rifaldi \n");

// Function dengan tipe data pada argument/parameter
function sum(int $first, int $last)
{
    $total = $first + $last;
    echo "total $first + $last = $total" . PHP_EOL;
}

sum(100, 100);
sum("100", "100");
sum(true, false);

// Function dengan variable argument list
function sumAll(...$values)
{
    $total = 0;
    foreach ($values as $value) {
        $total += $value;
    }
    echo "Total " . implode(",", $values) . " = $total" . PHP_EOL;
}

$values = [1, 2, 3, 4, 5];

sumAll(1, 2, 3, 4, 5);
sumAll(...$values);
