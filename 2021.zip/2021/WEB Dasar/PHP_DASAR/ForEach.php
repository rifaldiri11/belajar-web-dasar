<?php

$names = ["Muhamad", "Rifaldi", "Aldi"];

foreach ($names as $name) :
    echo "Hello $name" . PHP_EOL;
endforeach;

// foreach pada array MAP
$person = [
    "first_name" => "Muhamad",
    "middle_name" => "Rifaldi",
    "last_name" => "Aldi"
];

foreach ($person as $key => $value) {
    echo "$key : $value" . PHP_EOL;
}
