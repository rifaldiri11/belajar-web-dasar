<?php
// for loop
for ($counter = 1; $counter <= 20; $counter++) {
    echo "Ini adalah perulangan for loop ke-$counter" . PHP_EOL;
}

// While loop
$counter = 10;
while ($counter >= 5) {
    echo "Ini adalah perulangan while loop ke-$counter" . PHP_EOL;
    $counter--;
}

// do while loop
$counter = 100;
do {
    echo "Ini adalah perulangan do while loop ke-$counter" . PHP_EOL;
    $counter++;
} while ($counter <= 10);
