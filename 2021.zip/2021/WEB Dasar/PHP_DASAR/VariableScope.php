<?php

// variable scope

$name = "rifaldi"; // global scope

function sayName()
{
    // echo $name; // error

}

sayName();
