<?php

// sama dengan
var_dump("10" == 10);

// Identik
var_dump("10" === 10);

// Tidak sama dengan
var_dump(10 != 9);

// Tidak sama dengan
var_dump(10 <> 9);

// Tidak identik
var_dump(10 !== 10);

// Kurang dari
var_dump(10 < 10);

// Kurang dari atau Sama dengan
var_dump(10 <= 10);

// Lebih dari
var_dump(10 > 9);

// Lebih dari atau Sama dengan
var_dump(10 >= 11);
