<?php

$value = array(1, 2, 3, 4, 2.5);
var_dump($value);

$names = ["Muhamad", "Rifaldi", "Aldi"];
var_dump($names);

// Memanggil Data
var_dump($names[0]);

// Mengubah Data Berdasarkan urutan Index
$names[0] = "Budi";
var_dump($names);

// Mengahapus data beserta urutan index
unset($names[1]);
var_dump($names);

// Menambahkan Data
$names[] = "Bragi";
var_dump($names);

// Menghitung Jumlah Data
var_dump(count($names));

echo "MAP" . PHP_EOL;

// MAP DAN array di dalam array
$rifaldi = array(
    "id" => "aldi",
    "name" => "Muhamad Rifaldi",
    "age" => "21",
    "addres" => array(
        "city" => "Palembang",
        "country" => "Indonesia"
    )
);
var_dump($rifaldi);

var_dump($rifaldi["name"]);
var_dump($rifaldi["addres"]["country"]);

$anugrah = [
    "id" => "nugrah",
    "name" => "Anugrah Rizky Saputra",
    "age" => 20,
    "addres" => [
        "city" => "Palembang",
        "country" => "Indonesia"
    ]
];

var_dump($anugrah["id"]);
