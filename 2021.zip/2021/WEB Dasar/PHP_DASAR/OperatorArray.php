 <?php
    $first = [
        "first_name" => "Muhamad"
    ];

    $last = [
        "last_name" => "Rifaldi"
    ];
    // Menggabungkan
    var_dump($first + $last);

    $a = [
        "first_name" => "Muhamad",
        "last_name" => "Rifaldi"
    ];

    $b = [
        "last_name" => "Rifaldi",
        "first_name" => "Muhamad"
    ];
    // true jika memiliki key-value sama
    var_dump($a == $b);
    // true memiliki key-value dan posisi sama
    var_dump($a === $b);
