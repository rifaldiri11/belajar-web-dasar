<?php
echo 'Name : ';
echo 'Muhamad Rifaldi';

echo "\n";

echo 'Name : ';
echo "Muhamad\t Rifaldi\t S.Kom\n";
