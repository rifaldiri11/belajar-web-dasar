<?php

$name = "Muhamad Rifaldi";

// dot operator
echo "Name : " .  $name . PHP_EOL;
echo "Age : " .  21 . PHP_EOL;

// konversi number dan sebaliknya
$valueString = (string)100;
var_dump($valueString);

$valueInt = (int)"100";
var_dump($valueInt);

$valueFloat = (float)"1.01";
var_dump($valueFloat);

// mengakses karakter
$name = "Aldi";
echo $name[0] . PHP_EOL;
echo $name[2] . PHP_EOL;
echo $name[3] . PHP_EOL;

// variabel parshing
echo "Hello $name, Selamat Belajar " . PHP_EOL;

// curly brace
$booking = "booking";
echo "This is {$booking}s room" . PHP_EOL;
