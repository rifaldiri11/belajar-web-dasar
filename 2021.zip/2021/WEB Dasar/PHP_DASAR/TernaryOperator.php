<?php

$gender = "WANITA";
$hi = $gender == "PRIA" ? "Hi Bro" : "Hi Nona";
echo $hi . PHP_EOL;
