<?php

// menggunakan PHP 7.4

$data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// array_map
$dataResult = array_map(fn (int $value) => $value * 10, $data);
var_dump($dataResult);

// rsort yaitu mengebalikan urutan $data
rsort($data);
var_dump($data);
// sort yaitu mengebalikan data ke semula
sort($data);
var_dump($data);

$person = [
    "first_name" => "Muhamad",
    "last_name" => "Rifaldi"

];
var_dump(array_keys($person));
var_dump(array_values($person));
