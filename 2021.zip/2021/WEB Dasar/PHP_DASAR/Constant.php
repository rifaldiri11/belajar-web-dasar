<?php
define("AUTHOR", "Rifaldi Programmer");
define("APP_VERSION", 100);

echo "Author : ", AUTHOR, "\n";
echo "App Version : ", APP_VERSION, "\n";
