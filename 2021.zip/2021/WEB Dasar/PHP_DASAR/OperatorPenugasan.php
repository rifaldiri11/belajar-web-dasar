<?php

$total = 0;

$fruit = 5000;
$chicken = 10000;
$orangejuice = 5000;

$total += $fruit;
$total += $chicken;
$total += $orangejuice;

var_dump($total);
