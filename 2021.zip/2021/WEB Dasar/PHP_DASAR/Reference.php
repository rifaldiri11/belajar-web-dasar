<?php

$name = "Rifaldi";

$otherName = $name;

$otherName = &$name; // reference terhadap variable

$otherName = "Muhamad";

echo $name . PHP_EOL;


// assign by reference di parameter / argument pada function
function increment(int &$value)
{
    $value++;
}
$counter = 1;
increment($counter);
echo $counter . PHP_EOL;

// returning refences
function &getValue()
{
    static $value = 100;
    return $value;
}

$a = &getValue();
$a = 200;

$b = &getValue();
echo $a . PHP_EOL;
