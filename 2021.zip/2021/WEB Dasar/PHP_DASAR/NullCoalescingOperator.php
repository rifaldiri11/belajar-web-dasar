<?php

// NullCoalescingOperator "??"

$data = [
    "action" => null
];

$action = $data["action"] ?? "Nothing";

echo $action . PHP_EOL;
