<?php
$a = 10;
$b = 11;
$result = $a + $b;
var_dump($result);

$resultNegative = -$result;
var_dump($resultNegative);

$resultPositive = +$result;
var_dump($resultPositive);

$resultModulo = 44 % 5;
var_dump($resultModulo);
