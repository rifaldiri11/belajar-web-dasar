<?php

$name = "Rifaldi"; // global scope

function sayHello()
{
    global $name; // global keyword
    echo "Hello $name" . PHP_EOL;
}

sayHello();
