<?php

function createName()
{
    $name = "Rifaldi"; // local scope
}

createName();
echo $name . PHP_EOL; // error karena berada di luar area scope function
