<?php

// include & require berfungsi memanggil kode dari file lain

// masukkan folder dan file nya yang sudah di buat
// menambahkan kata kunci _once agar dapat memanggil nya beberapa kali
require_once "Lib/Myfunction.php";
require_once "Lib/Myfunction.php";

// error code
// require "Lib/Myfunction.php";
// require "Lib/Myfunction.php";


sayHello("Muhamad Rifaldi", 21);
