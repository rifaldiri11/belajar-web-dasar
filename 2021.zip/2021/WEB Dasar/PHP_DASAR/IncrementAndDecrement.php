<?php

$a = 10;

$b = $a++;
$a++;

echo "Ini a : ", var_dump($a);
echo "Ini b : ", var_dump($b);

$a -= 2;
echo "Ini a Minus : ", var_dump($a);
