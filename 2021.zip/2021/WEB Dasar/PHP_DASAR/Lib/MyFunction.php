<?php
function sayHello(string $name, int $age)
{
    echo "Hello nama saya $name dan usia saya $age tahun" . PHP_EOL;
}
