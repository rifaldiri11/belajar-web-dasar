<?php
echo "Ini Benar : ";
var_dump(true);

echo "Ini Salah : ";
var_dump(true);
