<?php

function increment()
{
    // kata kunci static disini menghidupkan life cycle dari variable counter
    static $counter = 1; // static scope
    echo "Counter = $counter " . PHP_EOL;
    $counter++;
}

increment();
increment();
increment();
increment();
increment();
