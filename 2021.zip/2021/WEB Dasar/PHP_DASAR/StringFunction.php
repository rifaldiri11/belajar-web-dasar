<?php
// menggabungkan 
var_dump(join(",", [10, 11, 12, 13, 14, 15]));
// menjadikan array
var_dump(explode(" ", "Muhamad Rifaldi Aldi"));
// mengecilkan format text
var_dump(strtolower("MUHAMAD RIFALDI ALDI"));
// membesarkan format text
var_dump(strtoupper("muhamad rifaldi aldi"));
// tidak mengambil spasi yang ada di awal dan akhir
var_dump(trim("        aldi         rifaldi    "));
// mengambil huruf dari 0 dan sampai 9
var_dump(substr("muhamadrifaldi", 0, 9));
