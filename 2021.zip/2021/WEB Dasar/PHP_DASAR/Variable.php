<?php
$name = "Muhamad Rifaldi";
$age = 21;

echo "Name : ", $name, "\n";

echo "Age : ", $age;
