<?php

// Break
$counter = 1;
while (true) {
    echo "Ini adalah perulangan while loop ke-$counter" . PHP_EOL;
    $counter++;

    if ($counter == 20) {
        break;
    }
}

// Continue
for ($counter = 1; $counter <= 20; $counter++) {
    if ($counter % 2 == 0) {
        continue;
    }
    echo "Counter : $counter" . PHP_EOL;
}
