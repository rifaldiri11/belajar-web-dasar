<?php

// menggunakan PHP 7.4
// arrow function

$firstName = "Muhamad";
$lastName = "Rifaldi";

$arrowFunction = fn () => "Hello $firstName $lastName" . PHP_EOL;

echo $arrowFunction();

// callback function
function sayHello(string $name, callable $filter)
{
    $finalName = call_user_func($filter, $name);
    echo "Hello $finalName" . PHP_EOL;
}

sayHello("Rifaldi", "strtoupper");
sayHello("Rifaldi", "strtolower");

// memanggil dengan anaonymous function
sayHello("Rifaldi", function (string $name): string {
    return strtoupper($name);
});

// memanggil dengan arrow function
sayHello("Rifaldi", fn ($name) => strtoupper($name));

// recursive function
