<?php

function sayHello()
{
    echo "Hello Function" . PHP_EOL;
}

sayHello();
sayHello();
sayHello();
